/*
Assignment for Introduction To Swift Programing
By: Philip Short
 
The following Swift code is the apply 5 different image filters and levels to an image.  Scroll to the bottom of the code to play around with the filters.

 
*/

import UIKit


// Class to be called
class ImageProcessor {
    
    init() {
        sourceImage = UIImage(named: "sample.png")!
        processedImage = sourceImage
        imageRGBA = RGBAImage(image: processedImage)!
    }
    
    let sourceImage : UIImage
    var processedImage : UIImage
    var imageRGBA : RGBAImage
    var filterChoice : [String : Int] = [:]
    
   
    
 internal func applyFilter() {
        for (filter, level) in filterChoice {
            Filter(filter, level: level)
        }
    }
    
 internal func addFilter(filter: String, level: Int) {
        filterChoice[filter] = level
   }
    
//Calculates the avgerage color for the color filter that is called ie. blue filter will only run blue
 internal func avgColor(color: String) -> Int {
        var pixelValue = 0
        for y in 0..<imageRGBA.height {
            for x in 0..<imageRGBA.width {
                let index = y * imageRGBA.width + x
                var pixel = imageRGBA.pixels[index]
                
                switch color {
                    case "Red":
                    pixelValue += Int(pixel.red)
                    case "Green":
                    pixelValue += Int(pixel.green)
                    case "Blue":
                    pixelValue += Int(pixel.blue)
                    default:
                    break
                }
            }
        }
        return pixelValue
    }
    
 
    
 // Calcuated the average value of color for the photo for the color filter selectd
 internal func Filter(filterName: String, level: Int) {
        let count = imageRGBA.height * imageRGBA.width
        var valueAvg = 0
        
        switch filterName {
            case "Red":
            valueAvg = avgColor("Red")/count
            case "Green":
            valueAvg = avgColor("Green")/count
            case "Blue":
            valueAvg = avgColor("Blue")/count
            default:
            break
        }
 //Apply filter based on filter selection and level
        
        for y in 0..<imageRGBA.height {
            for x in 0..<imageRGBA.width {
                let index = y * imageRGBA.width + x
                var pixel = imageRGBA.pixels[index]
                
                switch filterName {
                     // Red filter increases the average redness of the image by the selected level
                    case "Red":
                    let colorDiff = Int(pixel.red) - valueAvg
                    if (colorDiff > 0) {
                        pixel.red = UInt8(max(0, min(255, valueAvg + colorDiff + level)))
                        imageRGBA.pixels[index] = pixel
                    }
                     // Green filter increases the average greenness of the image by the selected level
                    case "Green":
                    let colorDiff = Int(pixel.green) - valueAvg
                    if (colorDiff > 0) {
                        pixel.green = UInt8(max(0, min(255, valueAvg + colorDiff + level)))
                        imageRGBA.pixels[index] = pixel
                    }
                    // Blue filter increases the average blueness of the image by the selected level
                    case "Blue":
                    let colorDiff = Int(pixel.blue) - valueAvg
                    if (colorDiff > 0) {
                        pixel.blue = UInt8(max(0, min(255, valueAvg + colorDiff + level)))
                        imageRGBA.pixels[index] = pixel
                    }
                   
                    //Color removing filter based on color to selected to be removed
                    case "Remove":
                        if (level == 1){
                            pixel.red = 0
                        }
                        if (level == 2){
                            pixel.green = 0
                        }
                        if (level == 3){
                            pixel.blue = 0
                        }
                        imageRGBA.pixels[index] = pixel
                
                    
                    //Greyscale equation is pulled from Wikipedia's artilce on it. It converts the RGB to greyscale pixel by pixel:
                    case "Grey":
                    let gray = 0.2126 * Double(pixel.red) + 0.7152 * Double(pixel.green) + 0.0722 * Double (pixel.blue)
                    let grayRounded = round(gray)
                    pixel.red = UInt8(grayRounded)
                    pixel.green = UInt8(grayRounded)
                    pixel.blue = UInt8(grayRounded)
                    imageRGBA.pixels[index] = pixel
                    
                    default:
                    break
                }
                
                
            }
        }
        
        processedImage = imageRGBA.toUIImage()!
    }
    
    
}

//---------------------------------------------------------------------------------------------//

var imagefilter = ImageProcessor()


/*                          FILTER AND INTESNITY SELECTION
 Select one or multiple of the following filters by un commenting them below:
 Red, Green, Blue, Greyscale, and Remove.
 
 Note 1: Intesnity level does not apply to greyscale filter.
 Note 2: To remove a color, set level to 1 for red, 2 for green, and 3 for blue
*/

//---------------------------------

//imagefilter.addFilter("Red", level: 15)
//imagefilter.addFilter("Green", level: -90)
//imagefilter.addFilter("Blue", level: 80)
imagefilter.addFilter("Grey", level: 0)
//imagefilter.addFilter("Remove", level: 1)

//---------------------------------

imagefilter.sourceImage
imagefilter.applyFilter()
imagefilter.processedImage

    

